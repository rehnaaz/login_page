
<?php
	$localhost = "localhost";
	$username = "root";
	$password = "";
	$dbName = "loginsystem";

	$con = mysqli_connect($localhost, $username, $password, $dbName);
	// print_r($con);

	if ($con) {
		//echo "Connection successfully";
	} else {
		//echo "Failed to connect";
	}

?>